§6Глава 12: 3D Модели предметов

§7В этой главе вы узнаете, как отображать интерактивные 3D модели предметов прямо в тексте гайда.
§6---
§bСинтаксис

§6`@item:id_предмета,размер,выравнивание`

§7Параметры:
• §eid_предмета§7 — идентификатор (например, minecraft:diamond)
• §eразмер§7 — размер отображения в пикселях (квадратный)
• §eвыравнивание§7 — left, center, right (по умолчанию center)
§6---
§bПримеры: Ресурсы и инструменты

§7§lАлмаз (по центру):
§6`@item:minecraft:diamond,100,center`

@item:minecraft:diamond,100,center

§7§lНезеритовый меч (слева):
§6`@item:minecraft:netherite_sword,100,left`

@item:minecraft:netherite_sword,100,left

§7§lТотем бессмертия (справа):
§6`@item:minecraft:totem_of_undying,100,right`

@item:minecraft:totem_of_undying,100,right
§6---
§bПримеры: Особые предметы

§7§lЗвезда Незера:
§6`@item:minecraft:nether_star,100,center`

@item:minecraft:nether_star,100,center

§7§lЯйцо дракона:
§6`@item:minecraft:dragon_egg,100,center`

@item:minecraft:dragon_egg,100,center

§7§lМузыкальный диск (11):
§6`@item:minecraft:music_disc_11,100,center`

@item:minecraft:music_disc_11,100,center
§6---
§bОсобенности

§7• Предметы **вращаются** в воздухе, как в инвентаре
§7• При наведении показывается §6тултип§7 с полным названием и размером стака
§7• §6Ленивая загрузка§7: модели загружаются только при прокрутке к ним (экономия памяти)
§7• Поддерживаются §6любые предметы§7 из ванильного Minecraft и модов
§7• Синтаксис аналогичен `@mob`, но проще (только один параметр размера)
§6---
§7§lСмотрите также:
[Сущности](entities) §7| [Крафты](crafts) §7| [Спойлеры](spoilers)