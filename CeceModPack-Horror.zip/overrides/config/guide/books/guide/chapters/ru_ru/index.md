introduction | Введение | minecraft:book
how_to_add | Главы | minecraft:writable_book
how_to_subchapters | Подглавы | minecraft:paper
syntax | Синтаксис и ссылки | minecraft:chain
crafts | Крафты и рецепты | minecraft:crafting_table
structures | Структуры | minecraft:stone_bricks
projection | Проекция | minecraft:spyglass
g_key_integration | Интеграция кнопки G | minecraft:stone_button
hot_reload | Команды и перезагрузка | minecraft:redstone_block
images_and_gifs | Картинки и анимации | minecraft:item_frame
entities | Сущности | minecraft:spawner
items | Предметы | minecraft:chest
spoilers | Спойлеры | minecraft:barrier
books | Создание книги | minecraft:lectern
cursor | Кастомные курсоры | minecraft:arrow
tables | Таблицы | minecraft:ladder
links | Ссылки и буфер обмена | minecraft:compass
quests | Интерактивные квесты | minecraft:target