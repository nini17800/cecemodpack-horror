§6Chapter 7: Camera System
§r
§7Almost every item from §6SecurityCraft§7 has been §cremoved§7.
§6---
§b§lThe only remaining items
§r
§6■ §7Camera
§6■ §7Camera Monitor
§r
§7Their crafting recipes have been §6redesigned§7 so they can be obtained during §anormal survival gameplay§7.
§6---
§bRequired Materials
§7Before crafting, make sure you have these on hand:
@inline_item:minecraft:glass
@inline_item:minecraft:glass_pane
@inline_item:minecraft:iron_ingot
@inline_item:minecraft:redstone_block
@inline_item:minecraft:stick
§7Hover over any item icon above to see its full name and description.
§6---
§bCamera Monitor
§7Eight glass panes surrounding a redstone block:
@matrix_craft:securitycraft:camera_monitor, minecraft:glass_pane, minecraft:glass_pane, minecraft:glass_pane, minecraft:glass_pane, minecraft:redstone_block, minecraft:glass_pane, minecraft:glass_pane, minecraft:glass_pane, minecraft:glass_pane,center
§7Replicate this layout in a standard crafting table to obtain the Camera Monitor.
§6---
§bSecurity Camera
§7Iron, glass, a redstone block, and a stick to hold it together:
@matrix_craft:securitycraft:security_camera, minecraft:iron_ingot, minecraft:iron_ingot, minecraft:iron_ingot, minecraft:glass, minecraft:redstone_block, minecraft:iron_ingot, minecraft:iron_ingot, minecraft:iron_ingot, minecraft:stick,center
§7Replicate this layout in a standard crafting table to obtain the Security Camera.
§6---
§7Use cameras to watch entrances, tunnels, and the edges of your base but remember the warning in §6Tips§7: §odon't always trust what you see§r§7.
§6---
§l§7See also:
§6[Camera Scare System](camera_scare) §7| §6[Starting Equipment](starting_equipment)
