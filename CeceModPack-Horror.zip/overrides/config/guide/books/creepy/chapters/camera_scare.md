§6Chapter 8: Camera Scare System
§e§o(Work in Progress)
§r
§7A custom §6Camera Scare§7 system is currently being developed.
§6---
§7Once completed, there will be a chance that while viewing one of your security cameras:
§r
§6■ §7An §centity suddenly appears§7 on the camera feed
§6■ §7A unique §cjumpscare§7 occurs
§6■ §7Strange or §cunexplained events§7 happen while watching the cameras
§6---
§7The goal is to make cameras both §auseful§7 and §cunsettling§7.
§6---
§8§oThis feature is still in development and may change before release.
§6---
§l§7See also:
§6[Camera System](camera_system) §7| §6[Future Content](future_content)
