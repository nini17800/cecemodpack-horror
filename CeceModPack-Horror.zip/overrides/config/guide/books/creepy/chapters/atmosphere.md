§6Chapter 10: Atmosphere
§r
§7The world §cchanges§7 the longer you survive.
§6---
§b§lExpect to encounter
§r
§6■ §7Fake chat messages
§6■ §7Fake join / leave notifications
§6■ §7Psychological chat events
§6■ §7Cave ambience
§6■ §7Stalkers watching from the darkness
§6■ §7Unexplained sounds
§6■ §7Strange visual encounters
§6---
§7Not every event has an immediate explanation.
§r
§7Sometimes the world simply wants you to §othink something is wrong§r§7.
§6---
§l§7See also:
§6[Entities](entities) §7| §6[Custom Join Messages](join_messages)
