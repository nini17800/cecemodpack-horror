introduction | Introduction | minecraft:book
sleeping | Sleeping | minecraft:red_bed
multiplayer | Multiplayer Features | minecraft:player_head
join_messages | Custom Join Messages | minecraft:writable_book
balancing | Gameplay Balancing | minecraft:comparator
starting_equipment | Starting Equipment | minecraft:bread
camera_system | Camera System | minecraft:spyglass
camera_scare | Camera Scare System | minecraft:ender_eye
entities | Entities | minecraft:spawner
atmosphere | Atmosphere | minecraft:soul_lantern
tips | Tips | minecraft:torch
future_content | Future Content | minecraft:nether_star
