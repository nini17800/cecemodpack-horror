§6Chapter 2: Sleeping
§r
§7Sleeping has been completely disabled§7.
§6---
§7You §ccannot skip the night§7. Players must survive until sunrise, making nighttime one of the §6most dangerous§7 parts of the game.
§r
§7The dark is when the world feels least safe  and when you are least alone.
§6---
§l§7See also:
§6[Introduction](introduction) §7| §6[Atmosphere](atmosphere)
