§6Chapter 6: Starting Equipment
§r
§7Every player starts with:
§r
§6■ §74 §6Security Cameras§7
§6■ §71 §6Camera Monitor§7
§6■ §716 §6Bread§7

§6■ §71 §6Guide§7
§6---
§7The cameras can be used to §6monitor important locations§7 while you explore the world.
§r
§7Set them up early they may be the only warning you get.
§6---
§l§7See also:
§6[Camera System](camera_system) §7| §6[Camera Scare System](camera_scare)
