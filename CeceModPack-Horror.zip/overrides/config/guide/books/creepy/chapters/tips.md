§6Chapter 11: Tips
§r
§7A few things worth remembering:
§6---
§6■ §7Always §6activate a nearby campfire§7 before exploring.
§6■ §7Nights §ccannot be skipped§7.
§6■ §7Read §6every note and signed book§7 you discover.
§6■ §7Cameras may save your life but §odon't always trust what you see§r§7.
§6■ §7Playing with friends is §ahighly recommended§7 for the full Creepy experience.
§6■ §7HAVE FUN
§6---
§l§7See also:
§6[Sleeping](sleeping) §7| §6[Camera System](camera_system)
