§6Chapter 3: Multiplayer Features
§r
§7Several vanilla multiplayer features have been §cintentionally removed or changed§7 to improve immersion.
§6---
§b§lWhat has changed
§r
§6■ §7Disabled §6Tab Player List§7
§6■ §7Disabled §6Mojang Social / Player Reporting§7 screen
§6■ §7Hidden online player information
§6---
§7Not always knowing §owho is online§r§7  or whether someone is actually §onearby§r§7  is part of the intended horror experience.
§6---
§l§7See also:
§6[Custom Join Messages](join_messages) §7| §6[Atmosphere](atmosphere)
