§6Chapter 9: Entities
§r
§7Various §6custom entities§7 inhabit the world. Each behaves differently.
§6---
§6■ §7Some §cstalk players§7 from afar
§6■ §7Some §cimitate others§7
§6■ §7Some only appear under §ccertain conditions§7
§r
§a★ §7= harmless   §e★ §7= kills you   §c★ §7= kills you §land§r§7 destroys blocks
§6---
§b§lThe Knocker
§r
§7§lThe Knocker §e★
§8§lIMAGE NOT FOUND
§7A pitch-black stalker with a pale, unsettling face. He tracks players back to their own base and, unpredictably, may visit while you sleep.
§r
§7§lKnocker (Stalking) §a★
§8§lIMAGE NOT FOUND
§7The Knocker on the move, closing in while unseen.
§r
§7§lKnocker (Spotted) §e★
§8§lIMAGE NOT FOUND
§7The Knocker's stance the instant he realizes he's been noticed.
§r
§7§lKnocker (Swimming) §e★
§8§lIMAGE NOT FOUND
§7Even water isn't safe  he follows through it just the same.
§6---
§b§lThe Stalker
§r
§7§lThe Stalker §a★
§8§lIMAGE NOT FOUND
§7Cannot move while directly observed  as long as your eyes are on it, you are safe. The moment you look away, it can close the distance without warning.
§r
§7§lTormentor §e★
§8§lIMAGE NOT FOUND
§7The most persistent form of the Stalker line, drawn to players who linger too long in one place.
§r
§7§lStalker (Following) §a★
§8§lIMAGE NOT FOUND
§7The active chase form, once it's decided you've looked away too long.
§r
§7§lStalker (Peeking) §a★
§8§lIMAGE NOT FOUND
§7Glimpsed at the edge of a doorway or corner, gone the instant you turn.
§r
§7§lStalker (Staring) §a★
§8§lIMAGE NOT FOUND
§7Motionless, fixed on you from a distance. Don't look away first.
§r
§7§lStalker (At the Window) §a★
§8§lIMAGE NOT FOUND
§7Found looking in from outside. Curtains exist for a reason.
§r
§7§lStalker (At the Door) §a★
§8§lIMAGE NOT FOUND
§7Waiting just outside a closed door.
§r
§7§lStalker (Door Ajar) §a★
§8§lIMAGE NOT FOUND
§7The door was closed. It isn't anymore.
§r
§7§lStalker (Bedside) §e★
§8§lIMAGE NOT FOUND
§7The one you never want to see when you wake up.
§r
§7§lStalker (On the Ladder) §a★
§8§lIMAGE NOT FOUND
§7Found clinging to ladders in mineshafts and towers, watching whoever climbs.
§6---
§b§lFace of Horror
§r
§7§lFace of Horror §a★
§8§lIMAGE NOT FOUND
§7Faces that flicker into view in dark or secluded areas, startling anyone nearby. Distant whispers, giggles, and voices sometimes precede a sighting  or arrive with nothing to see at all.
§r
§7§lHarvest Moon Spirit §e★
§8§lIMAGE NOT FOUND
§7A rare full-moon encounter. It descends before a player and demands an offering  give the correct one and you survive; refuse, and it may begin hunting until the night ends.
§6---
§b§lThe Watchers (DontCry)
§r
§7§lThe Watcher §a★
@mob:dontcry:dontcry,45,45,center
§7The base form of a presence with many faces.
§r
§7§lCave Stalker §e★
§8§lIMAGE NOT FOUND
§7Found deep underground, keeping pace just outside torchlight.
§r
§7§lCave Watcher §a★
§8§lIMAGE NOT FOUND
§7Doesn't follow  just watches from where the light doesn't reach.
§r
§7§lLittle Stalker §a★
§8§lIMAGE NOT FOUND
§7Smaller, quieter, and easier to miss than the others.
§r
§7§lOrimmy §c★
@mob:dontcry:orimmy,45,45,center
§7An unusual entity that doesn't quite behave like the rest.
§r
§7§lPhase One §e★
@mob:dontcry:phase1,45,45,center
§7An early-warning form  if you see this, something worse may follow.
§r
§7§lSmiler §c★
@mob:dontcry:smiler,45,45,center
§7Its expression never changes, no matter what it's doing.
§r
§7§lSquatter §a★
@mob:dontcry:squatter,45,45,center
§7Found crouched in corners and cramped spaces, waiting to be walked past.
§r
§7§lStalker §c★
@mob:dontcry:stalker,45,45,center
§7The line's standard chaser, drawn in by noise and light.
§r
§7§lStalking Night §e★
§8§lIMAGE NOT FOUND
§7Only active after dark. Sunrise is the only thing that sends it away.
§r
§7§lStare §e★
@mob:dontcry:stare,45,45,center
§7Doesn't move. Doesn't need to.
§r
§7§lTree Stalker §a★
§8§lIMAGE NOT FOUND
§7Blends into forests, standing still among the trunks until you pass too close.
§r
§7§lWindow Stalker §a★
§8§lIMAGE NOT FOUND
§7Looks in through windows at night. Don't look back.
§r
§7§lYelling Creature §e★
§8§lIMAGE NOT FOUND
§7You'll hear this one long before you see it.
§6---
§b§lOther Entities
§r
§7§lMinesis §c★
§8§lIMAGE NOT FOUND
§8§o(Details coming soon.)
§r
§7§lThe Mimic §a★
§8§lIMAGE NOT FOUND
§7Imitates what it isn't. Assume nothing you see is only what it appears to be.
§6---
§7More detail on individual creatures will be added as the story unfolds.
§6---
§l§7See also:
§6[Atmosphere](atmosphere) §7| §6[Future Content](future_content)
