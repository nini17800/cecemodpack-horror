§6Chapter 5: Gameplay Balancing
§r
§7Many mod configurations have been §6carefully customized§7.
§6---
§7Instead of overwhelming players with constant deaths, unfair mechanics, or excessive entity spam, numerous configs have been adjusted to create a §amore balanced§7 horror experience while still remaining §cchallenging§7.
§r
§7The goal is §6tension§7  §lnot frustration§r§7.
§6---
§l§7See also:
§6[Entities](entities) §7| §6[Tips](tips)
