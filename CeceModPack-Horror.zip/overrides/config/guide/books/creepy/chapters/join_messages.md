§6Chapter 4: Custom Join Messages
§r
§7Upon joining the server, you may receive a §6custom message§7 with information about:
§r
§6■ §7Thanks Message
§6■ §7Upcoming features or major updates
§6---
§7Additionally, §cfake join and leave messages §7 may occasionally appear as part of the psychological horror experience.
§r
§7If you see someone §ojoin§r§7 or §oleave§r§7  it may not be a real player at all. ( That is why we removed the chat indicator + tab )
§6---
§l§7See also:
§6[Multiplayer Features](multiplayer) §7| §6[Atmosphere](atmosphere)
