§6Chapter 12: Future Content
§r
§7The modpack continues to receive updates with new content and improvements.
§6---
§b§lPlanned additions
§r
§6■ §7Camera Scare System

§6---
§l§7See also:
§6[Camera Scare System](camera_scare) §7| §6[Introduction](introduction)

