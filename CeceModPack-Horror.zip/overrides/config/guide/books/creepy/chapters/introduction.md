§6Chapter 1: Introduction
§r
§7Welcome to §4Creepy §cHorror §7a modern, multiplayer-focused horror modpack built around psychological horror, exploration, survival, and immersion.
§r
§7Rather than relying on unfair difficulty, this modpack creates tension through §catmosphere§7, §cuncertainty§7, and the §cfear of the unknown§7. Many vanilla mechanics have been redesigned to support that experience while staying enjoyable in both multiplayer and singleplayer.
§6---
§b§lContents
§7Click any entry below to jump straight to that chapter:
§r
§6■ §7[Introduction](introduction)
§6■ §7[Sleeping](sleeping)
§6■ §7[Multiplayer Features](multiplayer)
§6■ §7[Custom Join Messages](join_messages)
§6■ §7[Gameplay Balancing](balancing)
§6■ §7[Starting Equipment](starting_equipment)
§6■ §7[Camera System](camera_system)
§6■ §7[Camera Scare System](camera_scare)
§6■ §7[Entities](entities)
§6■ §7[Atmosphere](atmosphere)
§6■ §7[Tips](tips)
§6■ §7[Future Content](future_content)
§6---
§7Use the §6left menu§7 to navigate at any time, and the §6search§7 to find things quickly.
§r
§7The goal is §6tension§7 not frustration.
§6---
§a★ Survive until sunrise. ★
